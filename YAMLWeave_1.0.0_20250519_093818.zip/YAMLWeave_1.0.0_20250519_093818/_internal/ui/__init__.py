"""YAMLWeave UI 包 - 提供YAMLWeave的用户界面功能"""

__version__ = "1.0.0"

# 使绝对导入的模块更易于访问
from code.ui.app_ui import YAMLWeaveUI
from code.ui.app_controller import AppController 