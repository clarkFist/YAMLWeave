#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YAMLWeave Controller 模块 - 连接UI和核心处理逻辑
"""

import os
import sys
import threading
import logging
import traceback
from typing import Callable, Dict, List, Optional, Any, Tuple

# 定义一个模拟的StubProcessor类，在无法导入真实类时使用
class MockStubProcessor:
    def __init__(self):
        self.logger = logging.getLogger('yamlweave')
        self.logger.error("使用了模拟的StubProcessor实现")
        self.yaml_file = None
    
    def set_yaml_file(self, yaml_file):
        self.yaml_file = yaml_file
        self.logger.warning(f"模拟StubProcessor: 设置YAML文件 {yaml_file}")
    
    def process_directory(self, root_dir):
        self.logger.warning(f"模拟StubProcessor: 无法处理目录 {root_dir}")
        return {
            "total_files": 0,
            "processed_files": 0,
            "successful_stubs": 0,
            "errors": [{
                "file": "N/A",
                "error": "StubProcessor未正确加载，无法执行处理"
            }]
        }

# 尝试各种导入方式
try:
    # 直接导入
    from core.stub_processor import StubProcessor
    found_real_processor = True
except ImportError:
    try:
        # 绝对导入
        from code.core.stub_processor import StubProcessor
        found_real_processor = True
    except ImportError:
        # 路径导入
        sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
        try:
            from core.stub_processor import StubProcessor
            found_real_processor = True
        except ImportError:
            # 与程序一起打包时，此模块可能不存在，使用模拟类
            StubProcessor = MockStubProcessor
            found_real_processor = False
            logging.getLogger('yamlweave').warning("无法导入StubProcessor，将使用模拟实现")

class AppController:
    """
    应用控制器，连接UI和核心处理
    """
    
    def __init__(self, ui=None):
        # 实例变量初始化 - 首先设置UI属性
        self.ui = ui
        
        # 日志系统初始化
        self.setup_logging()
        
        # 记录处理器初始化
        try:
            # 创建StubProcessor实例
            self.processor = StubProcessor()
            if not found_real_processor:
                self.log_warning("使用模拟的StubProcessor实现，功能将受限")
            else:
                self.log_info("成功初始化StubProcessor")
        except Exception as e:
            self.log_error(f"初始化处理器失败: {str(e)}")
            self.processor = None
        
        # UI回调设置
        if self.ui is not None:
            try:
                self.ui.set_process_callback(self.process_directory)
                self.log_info("成功设置处理回调")
            except Exception as e:
                self.log_error(f"设置UI回调失败: {str(e)}")
    
    def setup_logging(self):
        """设置日志系统"""
        # 创建日志目录
        os.makedirs('logs', exist_ok=True)
        
        # 日志配置
        self.logger = logging.getLogger('yamlweave')
        self.logger.setLevel(logging.INFO)
        
        # 确保不重复添加处理器
        if not self.logger.handlers:
            # 文件处理器
            file_handler = logging.FileHandler(os.path.join('logs', 'yamlweave.log'), encoding='utf-8')
            file_handler.setFormatter(logging.Formatter('%(asctime)s - %(levelname)s: %(message)s'))
            self.logger.addHandler(file_handler)
    
    def log_info(self, message):
        """记录信息级别日志"""
        self.logger.info(message)
        if self.ui:
            self.ui.log(f"[信息] {message}")
    
    def log_warning(self, message):
        """记录警告级别日志"""
        self.logger.warning(message)
        if self.ui:
            self.ui.log(f"[警告] {message}")
    
    def log_error(self, message):
        """记录错误级别日志"""
        self.logger.error(message)
        if self.ui:
            self.ui.log(f"[错误] {message}")
    
    def process_directory(self, root_dir, yaml_file=None):
        """处理目录"""
        if not root_dir or not os.path.isdir(root_dir):
            self.log_error(f"无效的目录路径: {root_dir}")
            return
        
        # 更新状态
        if self.ui:
            self.ui.update_status("正在处理...")
        
        # 创建并启动处理线程
        thread = threading.Thread(
            target=self._process_directory_thread,
            args=(root_dir, yaml_file)
        )
        thread.daemon = True
        thread.start()
    
    def _process_directory_thread(self, root_dir, yaml_file=None):
        """在独立线程中运行目录处理"""
        try:
            self.log_info(f"开始处理目录: {root_dir}")
            
            # 处理器检查
            if self.processor is None:
                self.log_error("处理器未初始化，无法执行操作")
                if self.ui:
                    self.ui.update_status("错误: 处理器未初始化")
                return
            
            # 设置YAML文件
            if yaml_file:
                self.log_info(f"使用YAML配置: {yaml_file}")
                self.processor.set_yaml_file(yaml_file)
            
            # 处理目录
            result = self.processor.process_directory(root_dir)
            
            # 处理结果
            self.log_info(f"文件总数: {result.get('total_files', 0)}")
            self.log_info(f"处理成功文件: {result.get('processed_files', 0)}")
            self.log_info(f"成功插入桩点: {result.get('successful_stubs', 0)}")
            
            # 如果有错误
            errors = result.get('errors', [])
            if errors:
                self.log_error(f"遇到 {len(errors)} 个错误")
                for error in errors:
                    self.log_error(f"  - {error.get('file')}: {error.get('error')}")
            
            # 更新状态
            if self.ui:
                self.ui.update_status(f"完成. 处理了 {result.get('processed_files', 0)} 个文件")
        except Exception as e:
            error_msg = f"处理目录时出错: {str(e)}"
            self.log_error(error_msg)
            self.log_error(traceback.format_exc())
            
            # 更新状态
            if self.ui:
                self.ui.update_status("处理时出错")


# def main():
#     """创建并启动应用"""
#     import tkinter as tk
#     from ..ui.app_ui import AutoStubUI  # 使用相对导入
    
#     root = tk.Tk()
#     app_ui = AutoStubUI(root)
#     controller = AppController(app_ui)
    
#     root.mainloop()


# if __name__ == "__main__":
#     main() 