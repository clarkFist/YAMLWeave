"""
日志配置模块
提供日志设置和获取功能
"""

import logging
import os
import sys
from datetime import datetime

# 日志级别映射
LOG_LEVELS = {
    'debug': logging.DEBUG,
    'info': logging.INFO,
    'warning': logging.WARNING,
    'error': logging.ERROR,
    'critical': logging.CRITICAL
}

# 日志格式
DEFAULT_LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

# 日志目录
LOG_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'logs')

def setup_logging(level='info', log_file=None, console=True):
    """
    设置日志系统
    
    Args:
        level: 日志级别，可选值: debug, info, warning, error, critical
        log_file: 日志文件名，如果为None则使用默认命名
        console: 是否输出到控制台
    
    Returns:
        logging.Logger: 根日志记录器
    """
    # 确保日志目录存在
    if not os.path.exists(LOG_DIR):
        os.makedirs(LOG_DIR)
    
    # 获取根日志记录器
    root_logger = logging.getLogger()
    root_logger.setLevel(LOG_LEVELS.get(level.lower(), logging.INFO))
    
    # 清除现有处理器
    for handler in root_logger.handlers[:]:
        root_logger.removeHandler(handler)
    
    # 创建格式化器
    formatter = logging.Formatter(DEFAULT_LOG_FORMAT)
    
    # 添加文件处理器
    if log_file is None:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        log_file = os.path.join(LOG_DIR, f'yamlweave_{timestamp}.log')
    
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setFormatter(formatter)
    root_logger.addHandler(file_handler)
    
    # 添加控制台处理器
    if console:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setFormatter(formatter)
        root_logger.addHandler(console_handler)
    
    return root_logger

def get_logger(name):
    """
    获取指定名称的日志记录器
    
    Args:
        name: 日志记录器名称
    
    Returns:
        logging.Logger: 日志记录器
    """
    return logging.getLogger(name)

def log_exception(logger, exception, prefix_message=""):
    """
    记录异常信息
    
    Args:
        logger: 日志记录器
        exception: 异常对象
        prefix_message: 前缀消息
        
    Returns:
        str: 格式化的错误消息
    """
    if prefix_message:
        error_message = f"{prefix_message}: {str(exception)}"
    else:
        error_message = str(exception)
        
    logger.exception(error_message)
    return error_message

def log_operation_result(logger, operation_name, success, message=""):
    """
    记录操作结果
    
    Args:
        logger: 日志记录器
        operation_name: 操作名称
        success: 是否成功
        message: 附加消息
        
    Returns:
        str: 格式化的结果消息
    """
    result = "成功" if success else "失败"
    log_message = f"{operation_name} {result}"
    
    if message:
        log_message += f": {message}"
        
    if success:
        logger.info(log_message)
    else:
        logger.error(log_message)
        
    return log_message

def setup_file_logger():
    """设置文件日志器，返回日志文件路径"""
    import time
    import os
    
    # 创建logs目录（如果不存在）
    logs_dir = "logs"
    if not os.path.exists(logs_dir):
        os.makedirs(logs_dir)
    
    # 日志文件命名规则：yamlweave_日期_时间.log
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_file = os.path.join(logs_dir, f"yamlweave_{timestamp}.log")
    
    # 配置文件处理器
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    
    # 详细的日志格式，包含更多上下文信息
    detailed_formatter = logging.Formatter(
        '%(asctime)s [%(levelname)s] %(name)s (%(filename)s:%(lineno)d) - %(message)s'
    )
    file_handler.setFormatter(detailed_formatter)
    
    # 设置文件日志级别为DEBUG，记录所有详细信息
    file_handler.setLevel(logging.DEBUG)
    
    # 将处理器添加到根日志器
    root_logger = logging.getLogger()
    root_logger.addHandler(file_handler)
    
    return log_file

def save_execution_log(stats, project_dir, backup_dir=None, stubbed_dir=None, detailed_stats=None):
    """
    保存执行日志到固定目录
    
    Args:
        stats: 统计信息字典
        project_dir: 项目目录
        backup_dir: 备份目录
        stubbed_dir: 插桩结果目录
        detailed_stats: 详细统计信息字典，包含更多项目相关数据
        
    Returns:
        str: 执行日志文件路径
    """
    import time
    import os
    import json
    import platform
    import datetime
    
    # 创建执行日志目录
    exec_logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "execution_logs")
    if not os.path.exists(exec_logs_dir):
        os.makedirs(exec_logs_dir)
    
    # 创建带时间戳的执行日志文件
    timestamp = time.strftime("%Y%m%d_%H%M%S")
    log_filename = f"execution_{timestamp}.log"
    log_file_path = os.path.join(exec_logs_dir, log_filename)
    
    # 获取当前时间的格式化字符串
    current_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    
    # 组织执行结果信息
    execution_info = {
        "timestamp": timestamp,
        "formatted_time": current_time,
        "project_directory": project_dir,
        "stats": stats,
        "backup_directory": backup_dir,
        "stubbed_directory": stubbed_dir
    }
    
    # 如果有详细统计信息，则添加到执行信息中
    if detailed_stats:
        execution_info["detailed_stats"] = detailed_stats
    else:
        # 如果没有提供详细统计，则至少添加一些基本系统信息
        execution_info["system_info"] = {
            "os": platform.system(),
            "os_version": platform.version(),
            "platform": platform.platform(),
            "python_version": platform.python_version(),
            "timestamp": current_time
        }
    
    # 格式化结果信息
    result_lines = []
    result_lines.append(f"===== 执行日志：{timestamp} ({current_time}) =====")
    result_lines.append(f"项目目录: {project_dir}")
    
    if backup_dir:
        result_lines.append(f"备份目录: {backup_dir}")
        
    if stubbed_dir:
        result_lines.append(f"插桩结果目录: {stubbed_dir}")
    
    result_lines.append("\n----- 执行统计 -----")
    
    if stats:
        scanned = stats.get('scanned_files', 0)
        updated = stats.get('updated_files', 0)
        inserted = stats.get('inserted_stubs', 0)
        failed = stats.get('failed_files', 0)
        
        result_lines.append(f"总扫描文件数: {scanned}")
        result_lines.append(f"更新的文件数: {updated}")
        result_lines.append(f"插入的桩点数: {inserted}")
        
        if failed > 0:
            result_lines.append(f"处理失败文件: {failed}")
        
        # 计算成功率
        if scanned > 0:
            update_rate = updated / scanned * 100
            result_lines.append(f"文件更新率: {update_rate:.1f}%")
        
        # 计算桩点插入效率
        if updated > 0:
            stub_per_file = inserted / updated
            result_lines.append(f"平均每文件桩点: {stub_per_file:.1f}")
    
    # 添加详细统计信息到日志
    if detailed_stats:
        # 系统环境信息
        system_info = detailed_stats.get("system_info", {})
        if system_info:
            result_lines.append("\n----- 系统环境信息 -----")
            result_lines.append(f"操作系统: {system_info.get('os', '未知')} {system_info.get('os_version', '未知')}")
            result_lines.append(f"平台: {system_info.get('platform', '未知')}")
            result_lines.append(f"Python版本: {system_info.get('python_version', '未知')}")
            result_lines.append(f"处理器: {system_info.get('processor', '未知')}")
            result_lines.append(f"主机名: {system_info.get('hostname', '未知')}")
            result_lines.append(f"时区: {system_info.get('timezone', '未知')}")
        
        # 文件类型统计
        file_types = detailed_stats.get("file_types", {})
        if file_types:
            result_lines.append("\n----- 文件类型统计 -----")
            for ext, count in sorted(file_types.items(), key=lambda x: x[1], reverse=True):
                result_lines.append(f"{ext}: {count} 个文件")
        
        # 文件大小统计
        file_sizes = detailed_stats.get("file_sizes", {})
        if file_sizes:
            result_lines.append("\n----- 文件大小统计 -----")
            total_bytes = file_sizes.get("total_size_bytes", 0)
            avg_bytes = file_sizes.get("avg_size_bytes", 0)
            max_bytes = file_sizes.get("max_size_bytes", 0)
            min_bytes = file_sizes.get("min_size_bytes", 0)
            
            # 格式化字节大小为KB/MB
            def format_size(size_in_bytes):
                if size_in_bytes < 1024:
                    return f"{size_in_bytes} B"
                elif size_in_bytes < 1024*1024:
                    return f"{size_in_bytes/1024:.2f} KB"
                else:
                    return f"{size_in_bytes/(1024*1024):.2f} MB"
            
            result_lines.append(f"总大小: {format_size(total_bytes)}")
            result_lines.append(f"平均大小: {format_size(avg_bytes)}")
            result_lines.append(f"最大文件: {format_size(max_bytes)} - {os.path.basename(file_sizes.get('max_size_file', ''))}")
            if min_bytes > 0:
                result_lines.append(f"最小文件: {format_size(min_bytes)} - {os.path.basename(file_sizes.get('min_size_file', ''))}")
    
    result_lines.append("\n=====================")
    
    # 写入执行日志文件
    try:
        with open(log_file_path, 'w', encoding='utf-8') as f:
            # 写入格式化结果
            f.write('\n'.join(result_lines))
            f.write('\n\n')
            
            # 写入JSON格式数据供程序解析
            f.write("--- JSON数据 ---\n")
            f.write(json.dumps(execution_info, ensure_ascii=False, indent=2))
        
        return log_file_path
    except Exception as e:
        logging.error(f"保存执行日志失败: {str(e)}")
        return None

def get_execution_logs():
    """
    获取执行日志历史记录
    
    Returns:
        list: 执行日志文件列表，按时间降序排序
    """
    import os
    import json
    import time
    from datetime import datetime
    
    # 执行日志目录
    exec_logs_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), "execution_logs")
    if not os.path.exists(exec_logs_dir):
        return []
    
    log_files = []
    
    # 遍历执行日志目录中的所有日志文件
    for filename in os.listdir(exec_logs_dir):
        if filename.startswith("execution_") and filename.endswith(".log"):
            file_path = os.path.join(exec_logs_dir, filename)
            
            # 获取文件修改时间
            file_mtime = os.path.getmtime(file_path)
            file_mtime_str = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(file_mtime))
            
            # 尝试从文件内容中解析执行信息
            execution_info = {}
            try:
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = f.read()
                    
                    # 查找JSON数据部分
                    json_start = content.find("--- JSON数据 ---")
                    if json_start > 0:
                        json_data = content[json_start + len("--- JSON数据 ---"):].strip()
                        execution_info = json.loads(json_data)
            except Exception:
                # 如果无法解析JSON，使用基本信息
                pass
            
            # 创建日志文件记录
            log_record = {
                "file_path": file_path,
                "file_name": filename,
                "modified_time": file_mtime,
                "modified_time_str": file_mtime_str,
                "execution_info": execution_info
            }
            
            log_files.append(log_record)
    
    # 按修改时间降序排序
    log_files.sort(key=lambda x: x["modified_time"], reverse=True)
    
    return log_files

def get_execution_log_stats():
    """
    获取执行日志统计信息
    
    Returns:
        dict: 执行日志统计信息，包括总日志数、最新日志时间等
    """
    log_files = get_execution_logs()
    
    if not log_files:
        return {
            "total_logs": 0,
            "latest_log": None,
            "total_processed_files": 0,
            "total_inserted_stubs": 0
        }
    
    # 统计插桩文件总数和桩点总数
    total_processed_files = 0
    total_inserted_stubs = 0
    
    for log in log_files:
        execution_info = log.get("execution_info", {})
        stats = execution_info.get("stats", {})
        
        total_processed_files += stats.get("updated_files", 0)
        total_inserted_stubs += stats.get("inserted_stubs", 0)
    
    return {
        "total_logs": len(log_files),
        "latest_log": log_files[0] if log_files else None,
        "total_processed_files": total_processed_files,
        "total_inserted_stubs": total_inserted_stubs
    }

def get_latest_execution_log_content():
    """
    获取最近执行日志的内容
    
    Returns:
        str: 最近执行日志的文本内容，如果没有则返回None
    """
    logs = get_execution_logs()
    if not logs:
        return None
    
    latest_log = logs[0]
    log_path = latest_log.get("file_path")
    
    try:
        with open(log_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content
    except Exception as e:
        logging.error(f"读取最近执行日志失败: {str(e)}")
        return None

def get_execution_log_content(log_index=0):
    """
    获取指定索引的执行日志内容
    
    Args:
        log_index: 日志索引，0表示最新的日志
        
    Returns:
        tuple: (日志内容, 日志记录)，如果没有则返回(None, None)
    """
    logs = get_execution_logs()
    if not logs or log_index >= len(logs):
        return None, None
    
    log_record = logs[log_index]
    log_path = log_record.get("file_path")
    
    try:
        with open(log_path, 'r', encoding='utf-8') as f:
            content = f.read()
        return content, log_record
    except Exception as e:
        logging.error(f"读取执行日志失败: {str(e)}")
        return None, log_record 