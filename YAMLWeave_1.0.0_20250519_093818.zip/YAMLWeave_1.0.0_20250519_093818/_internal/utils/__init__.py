"""
YAMLWeave 工具模块
提供YAMLWeave的通用工具功能
""" 