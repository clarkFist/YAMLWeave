#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
YAMLWeave Core 模块 - stub_processor
负责插桩处理的核心逻辑
"""

import os
import sys
import re
import logging
from pathlib import Path
from typing import Dict, List, Tuple, Set, Optional, Any, Union
import datetime
import shutil

# 定义模拟类，当实际类无法加载时使用
class MockYamlStubHandler:
    def __init__(self, yaml_file_path=None):
        self.logger = logging.getLogger('yamlweave.core')
        self.logger.warning("使用模拟的YamlStubHandler实现")
        self.yaml_file_path = yaml_file_path
        self.yaml_data = {}
    
    def load_yaml(self, yaml_file_path):
        self.yaml_file_path = yaml_file_path
        self.logger.info(f"模拟加载YAML文件: {yaml_file_path}")
        return True
    
    def get_stub_code(self, test_case_id, step_id, segment_id):
        self.logger.warning(f"模拟获取桩代码: {test_case_id}.{step_id}.{segment_id}")
        return None
    
    def is_yaml_loaded(self):
        return self.yaml_file_path is not None

class MockCommentHandler:
    def __init__(self):
        self.logger = logging.getLogger('yamlweave.core')
        self.logger.warning("使用模拟的CommentHandler实现")
    
    def extract_stub_code(self, comment_line):
        self.logger.warning(f"模拟从注释提取代码: {comment_line}")
        return None
    
    def parse_stub_anchor(self, comment_line):
        # 简单解析锚点信息
        parts = comment_line.strip().split()
        if len(parts) >= 3 and parts[0].startswith("//"):
            if parts[1].upper().startswith("TC") and parts[2].upper().startswith("STEP"):
                if len(parts) >= 4:
                    return parts[1], parts[2], parts[3], ""
        return None, None, None, None

try:
    from YAMLWeave.utils.logger import get_logger
    logger = get_logger(__name__)
except ImportError:
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(handler)
    logger.error("尝试使用YAMLWeave前缀导入")

# 导入标记，默认为未加载
handlers_loaded = False

# 尝试导入处理器模块（分多步尝试）
# 步骤1：从YAMLWeave包导入
try:
    from YAMLWeave.handlers.comment_handler import CommentHandler
    from YAMLWeave.handlers.yaml_handler import YamlStubHandler
    handlers_loaded = True
    logger.info("成功从YAMLWeave包导入处理器")
except ImportError:
    logger.warning("从YAMLWeave包导入处理器失败，尝试其他方法")

# 步骤2：从相对路径导入
if not handlers_loaded:
    try:
        # 获取handlers目录路径
        handlers_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "handlers")
        if os.path.exists(handlers_path):
            # 添加到sys.path
            parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            sys.path.insert(0, parent_dir)
            
            # 尝试导入
            try:
                from handlers.comment_handler import CommentHandler
                from handlers.yaml_handler import YamlStubHandler
                handlers_loaded = True
                logger.info(f"成功从{handlers_path}导入处理器模块")
            except ImportError:
                logger.warning(f"从{handlers_path}导入处理器模块失败，尝试下一种方法")
        else:
            logger.warning(f"处理器目录不存在: {handlers_path}")
    except Exception as e:
        logger.error(f"尝试从相对路径导入处理器失败: {str(e)}")

# 步骤3：动态导入
if not handlers_loaded:
    try:
        import importlib.util
        
        # 动态导入handlers模块
        handlers_path = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "handlers")
        if os.path.exists(handlers_path):
            comment_handler_path = os.path.join(handlers_path, "comment_handler.py")
            yaml_handler_path = os.path.join(handlers_path, "yaml_handler.py")
            
            if os.path.exists(comment_handler_path) and os.path.exists(yaml_handler_path):
                # 导入comment_handler
                spec = importlib.util.spec_from_file_location(
                    "comment_handler", 
                    comment_handler_path
                )
                comment_handler_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(comment_handler_module)
                CommentHandler = comment_handler_module.CommentHandler
                
                # 导入yaml_handler
                spec = importlib.util.spec_from_file_location(
                    "yaml_handler", 
                    yaml_handler_path
                )
                yaml_handler_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(yaml_handler_module)
                YamlStubHandler = yaml_handler_module.YamlStubHandler
                
                handlers_loaded = True
                logger.info("成功从文件路径动态导入处理器模块")
            else:
                logger.error("无法找到必要的处理器模块文件")
        else:
            logger.error(f"处理器目录不存在: {handlers_path}")
    except Exception as e:
        logger.error(f"动态导入处理器模块失败: {str(e)}")

# 如果无法加载实际处理器，使用模拟实现
if not handlers_loaded:
    logger.error("无法导入YamlStubHandler和CommentHandler，将使用模拟实现")
    CommentHandler = MockCommentHandler
    YamlStubHandler = MockYamlStubHandler

# 使用适应性导入方式，避免相对导入错误
try:
    # 尝试直接导入
    from core.stub_parser import StubParser, read_file, write_file, find_c_files
    parser_loaded = True
except ImportError:
    try:
        # 尝试从当前目录导入
        from stub_parser import StubParser, read_file, write_file, find_c_files
        parser_loaded = True
    except ImportError:
        try:
            # 尝试相对导入
            from .stub_parser import StubParser, read_file, write_file, find_c_files
            parser_loaded = True
        except ImportError:
            sys.path.append(os.path.dirname(os.path.abspath(__file__)))
            try:
                # 最后尝试直接导入
                from stub_parser import StubParser, read_file, write_file, find_c_files
                parser_loaded = True
            except ImportError:
                logger.error("无法导入stub_parser模块，核心功能将不可用")
                # 创建占位函数和类，使程序不会崩溃
                def read_file(file_path):
                    logger.warning(f"模拟读取文件: {file_path}")
                    return ""
                
                def write_file(file_path, content):
                    logger.warning(f"模拟写入文件: {file_path}")
                    pass
                
                def find_c_files(root_dir):
                    logger.warning(f"模拟查找C文件: {root_dir}")
                    return []
                
                class StubParser:
                    def __init__(self, yaml_handler=None):
                        self.logger = logging.getLogger('yamlweave.core')
                        self.logger.warning("使用模拟的StubParser实现")
                        self.yaml_handler = yaml_handler
                    
                    def process_file(self, file_path):
                        self.logger.warning(f"模拟处理文件: {file_path}")
                        return True, "模拟处理", 0
                
                parser_loaded = False

class StubProcessor:
    """
    桩处理器类
    支持两种工作模式：从注释提取代码和从YAML加载代码
    """
    
    def __init__(self, project_dir: Optional[str] = None, yaml_file_path: Optional[str] = None):
        """
        初始化桩处理器
        
        Args:
            project_dir: 项目目录路径，可选
            yaml_file_path: YAML配置文件路径，可选
        """
        # 初始化日志
        self.logger = logging.getLogger("yamlweave.core")
        
        # 初始化变量
        self.project_dir = project_dir
        self.yaml_file_path = yaml_file_path
        self.using_mocks = not (handlers_loaded and parser_loaded)
        
        # 记录功能状态
        if self.using_mocks:
            self.logger.warning("某些功能模块未加载，将使用模拟实现，功能受限")
        
        # 实例化处理器组件
        try:
            # 初始化YAML处理器
            self.yaml_handler = YamlStubHandler(yaml_file_path)
            if yaml_file_path and os.path.exists(yaml_file_path):
                self.yaml_handler.load_yaml(yaml_file_path)
            
            # 初始化注释处理器
            self.comment_handler = CommentHandler()
            
            # 初始化解析器
            self.parser = StubParser(self.yaml_handler)
            
            self.logger.info("桩处理器组件初始化完成")
        except Exception as e:
            self.logger.error(f"初始化桩处理器组件失败: {str(e)}")
            self.using_mocks = True
            
            # 确保即使出错也有可用的组件
            self.yaml_handler = YamlStubHandler(yaml_file_path)
            self.comment_handler = CommentHandler()
            self.parser = StubParser(self.yaml_handler)
    
    def set_yaml_file(self, yaml_file_path: str) -> bool:
        """设置YAML配置文件路径"""
        self.logger.info(f"设置YAML配置文件: {yaml_file_path}")
        self.yaml_file_path = yaml_file_path
        
        # 实际加载YAML配置
        try:
            if os.path.exists(yaml_file_path):
                success = self.yaml_handler.load_yaml(yaml_file_path)
                if success:
                    self.logger.info(f"成功加载YAML配置文件: {yaml_file_path}")
                    return True
                else:
                    self.logger.error(f"加载YAML配置文件失败: {yaml_file_path}")
            else:
                self.logger.error(f"YAML配置文件不存在: {yaml_file_path}")
        except Exception as e:
            self.logger.error(f"设置YAML配置文件时出错: {str(e)}")
        
        return False
    
    def process_file(self, file_path: str) -> Tuple[bool, str, int]:
        """
        处理单个文件，插入桩代码
        
        Args:
            file_path: 文件路径
            
        Returns:
            Tuple[bool, str, int]: (成功/失败, 消息, 插入桩点数量)
        """
        self.logger.info(f"处理文件: {file_path}")
        
        if self.using_mocks:
            self.logger.warning(f"使用模拟处理: {file_path}")
            return True, "成功 (模拟)", 0
        
        # 实际处理文件
        try:
            if not os.path.exists(file_path):
                return False, f"文件不存在: {file_path}", 0
            
            # 处理文件并返回结果
            success, message, count = self.parser.process_file(file_path)
            
            if success:
                self.logger.info(f"文件处理成功: {file_path}, 插入了 {count} 个桩点")
            else:
                self.logger.warning(f"文件处理失败: {file_path}, {message}")
            
            return success, message, count
        except Exception as e:
            error_msg = f"处理文件时出错: {str(e)}"
            self.logger.error(error_msg)
            return False, error_msg, 0
    
    def process_directory(self, root_dir: str) -> Dict[str, Any]:
        """
        处理目录
        
        Args:
            root_dir: 项目根目录
            
        Returns:
            Dict[str, Any]: 处理结果
        """
        self.logger.info(f"处理目录: {root_dir}")
        
        # 初始化结果统计
        result = {
            "total_files": 0,
            "processed_files": 0,
            "successful_stubs": 0,
            "errors": []
        }
        
        # 如果使用模拟模式，返回模拟结果
        if self.using_mocks:
            self.logger.warning(f"使用模拟处理目录: {root_dir}")
            result["total_files"] = 4
            result["processed_files"] = 4
            result["successful_stubs"] = 0
            return result
        
        # 实际处理目录
        try:
            # 检查目录是否存在
            if not os.path.isdir(root_dir):
                result["errors"].append({"file": "N/A", "error": f"目录不存在: {root_dir}"})
                return result
            
            # 查找所有C文件
            c_files = find_c_files(root_dir)
            result["total_files"] = len(c_files)
            
            # 处理每个文件
            for file_path in c_files:
                try:
                    success, message, count = self.process_file(file_path)
                    
                    if success:
                        result["processed_files"] += 1
                        result["successful_stubs"] += count
                    else:
                        result["errors"].append({"file": file_path, "error": message})
                except Exception as e:
                    error_msg = f"处理文件时出错: {str(e)}"
                    self.logger.error(error_msg)
                    result["errors"].append({"file": file_path, "error": error_msg})
            
            self.logger.info(f"目录处理完成: {root_dir}")
            self.logger.info(f"总文件数: {result['total_files']}")
            self.logger.info(f"处理文件数: {result['processed_files']}")
            self.logger.info(f"插入桩点数: {result['successful_stubs']}")
            if result["errors"]:
                self.logger.warning(f"处理错误数: {len(result['errors'])}")
        except Exception as e:
            error_msg = f"处理目录时出错: {str(e)}"
            self.logger.error(error_msg)
            result["errors"].append({"file": "N/A", "error": error_msg})
        
        return result
    
    def process_files(self, callback=None) -> Tuple[bool, str, Dict[str, Any]]:
        """
        处理文件并插入桩代码（与MinimalStubProcessor接口兼容）
        
        Args:
            callback: 可选的进度回调函数，接受文件路径和更新状态参数
            
        Returns:
            Tuple[bool, str, Dict[str, Any]]: (成功/失败, 消息, 统计信息)
        """
        # 检查项目目录是否有效
        if not self.project_dir or not os.path.isdir(self.project_dir):
            error_msg = f"项目目录无效: {self.project_dir}"
            self.logger.error(error_msg)
            return False, error_msg, {}
        
        # 初始化统计信息
        self.stats = {
            "scanned_files": 0,
            "updated_files": 0,
            "inserted_stubs": 0,
            "failed_files": 0
        }
        
        try:
            # 首先备份整个项目目录
            timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
            backup_dir = f"{self.project_dir}_backup_{timestamp}"
            self.backup_dir = backup_dir  # 保存为实例属性
            
            try:
                self.logger.info(f"开始备份整个项目目录: {self.project_dir} -> {backup_dir}")
                
                # 复制整个目录
                shutil.copytree(self.project_dir, backup_dir)
                self.logger.info(f"项目目录备份成功: {backup_dir}")
                
                # 创建插桩结果目录
                stubbed_dir = f"{self.project_dir}_stubbed_{timestamp}"
                self.stubbed_dir = stubbed_dir  # 保存为实例属性
                self.logger.info(f"创建插桩结果目录: {stubbed_dir}")
                
                # 复制项目目录作为插桩结果目录的基础
                shutil.copytree(self.project_dir, stubbed_dir)
            except Exception as backup_error:
                error_msg = f"项目目录备份失败: {str(backup_error)}"
                self.logger.error(error_msg)
                return False, error_msg, self.stats
            
            # 扫描所有.c和.h文件
            self.logger.info(f"开始扫描目录: {self.project_dir}")
            
            c_files = []
            for root, _, files in os.walk(self.project_dir):
                for file in files:
                    if file.endswith('.c') or file.endswith('.h'):
                        c_files.append(os.path.join(root, file))
            
            self.stats["scanned_files"] = len(c_files)
            total_files = len(c_files)
            
            if total_files == 0:
                warning_msg = f"目录中未找到C文件: {self.project_dir}"
                self.logger.warning(warning_msg)
                return True, warning_msg, self.stats
            
            self.logger.info(f"找到 {total_files} 个C/H文件")
            
            # 处理每个文件
            for i, file_path in enumerate(c_files):
                try:
                    # 读取文件内容
                    try:
                        with open(file_path, 'r', encoding='utf-8') as f:
                            content = f.read()
                    except UnicodeDecodeError:
                        # 尝试其他编码
                        try:
                            with open(file_path, 'r', encoding='gbk') as f:
                                content = f.read()
                            self.logger.info(f"使用GBK编码成功读取文件: {file_path}")
                        except Exception as enc_error:
                            error_msg = f"无法读取文件: {file_path}, 错误: {str(enc_error)}"
                            self.logger.error(error_msg)
                            self.stats["failed_files"] += 1
                            continue
                    except Exception as f_error:
                        error_msg = f"读取文件失败: {file_path}, 错误: {str(f_error)}"
                        self.logger.error(error_msg)
                        self.stats["failed_files"] += 1
                        continue
                    
                    # 处理文件
                    success, message, count = self.process_file(file_path)
                    updated = (count > 0)
                    
                    if success and updated:
                        self.stats["updated_files"] += 1
                        self.stats["inserted_stubs"] += count
                        
                        # 处理.stub文件并复制到结果目录
                        try:
                            # 获取相对路径
                            rel_path = os.path.relpath(file_path, self.project_dir)
                            stub_file_path = os.path.join(stubbed_dir, rel_path)
                            
                            # 确保目标目录存在
                            stub_dir = os.path.dirname(stub_file_path)
                            os.makedirs(stub_dir, exist_ok=True)
                            
                            # 复制.stub文件到结果目录，并重命名为原文件名
                            source_stub = file_path + ".stub"
                            if os.path.exists(source_stub):
                                with open(source_stub, 'r', encoding='utf-8', errors='replace') as f:
                                    stub_content = f.read()
                                with open(stub_file_path, 'w', encoding='utf-8', errors='replace') as f:
                                    f.write(stub_content)
                                self.logger.info(f"复制处理后文件到结果目录: {stub_file_path}")
                                
                                # 删除原始.stub文件(清理)
                                try:
                                    os.remove(source_stub)
                                except:
                                    pass
                            else:
                                self.logger.warning(f"找不到处理后的.stub文件: {source_stub}")
                        except Exception as copy_error:
                            self.logger.error(f"复制文件到结果目录失败: {str(copy_error)}")
                    elif not success:
                        self.stats["failed_files"] += 1
                    
                    # 回调进度函数
                    if callback:
                        callback(file_path, updated)
                    
                except Exception as p_error:
                    error_msg = f"处理文件内容失败: {file_path}, 错误: {str(p_error)}"
                    self.logger.error(error_msg)
                    self.stats["failed_files"] += 1
                    continue
            
            # 构建完成消息
            success_msg = f"处理完成: 扫描了 {self.stats['scanned_files']} 个文件，更新了 {self.stats['updated_files']} 个文件，插入了 {self.stats['inserted_stubs']} 个桩代码"
            self.logger.info(success_msg)
            
            # 添加备份和结果目录到消息
            result_msg = f"{success_msg}\n备份目录: {backup_dir}\n插桩结果目录: {stubbed_dir}"
            
            return True, result_msg, self.stats
            
        except Exception as e:
            error_msg = f"处理文件过程中发生错误: {str(e)}"
            self.logger.error(error_msg)
            import traceback
            self.logger.error(traceback.format_exc())
            return False, error_msg, self.stats

def main():
    """命令行入口点"""
    if len(sys.argv) < 2:
        print("用法: python -m YAMLWeave.core.stub_processor <项目目录> [YAML配置文件]")
        return
    
    root_dir = sys.argv[1]
    if not os.path.isdir(root_dir):
        print(f"错误: '{root_dir}' 不是有效目录")
        return
    
    yaml_file = None
    if len(sys.argv) > 2:
        yaml_file = sys.argv[2]
        if not os.path.exists(yaml_file):
            print(f"错误: YAML配置文件 '{yaml_file}' 不存在")
            return
    
    processor = StubProcessor(root_dir, yaml_file)
    processor.process_directory(root_dir)

if __name__ == "__main__":
    main() 