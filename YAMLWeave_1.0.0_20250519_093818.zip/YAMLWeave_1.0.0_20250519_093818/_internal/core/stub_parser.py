"""
桩注释解析模块 (优化版)
支持从YAML配置文件加载桩代码和识别新格式锚点

本模块实现了note.md中描述的"锚点与桩代码分离"机制，支持以下锚点格式：

```c
// TC001 STEP1 segment1
// TC001 STEP1 segment2
```

桩代码从外部YAML配置文件加载，支持多个步骤和代码段的组织结构。
"""

import re
import os
import chardet
from typing import List, Dict, Any, Optional, Tuple

try:
    from YAMLWeave.utils.logger import get_logger
    logger = get_logger(__name__)
except ImportError:
    import logging
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter('%(levelname)s: %(message)s'))
    logger.addHandler(handler)

try:
    from YAMLWeave.handlers.yaml_handler import YamlStubHandler
except ImportError:
    logger.error("无法导入YamlStubHandler，锚点与桩代码分离功能将不可用")
    YamlStubHandler = None

class StubParser:
    """
    增强的桩注释解析器，支持YAML配置和新格式锚点
    
    支持两种主要工作模式:
    1. 传统模式：识别注释中内嵌的代码字段
    2. 分离模式：识别锚点标识，从YAML配置文件中加载对应的桩代码
    
    第二种模式实现了note.md中描述的"锚点与桩代码分离"机制，
    提升源代码清晰度与桩代码复用性。
    """
    
    def __init__(self, yaml_handler: Optional[YamlStubHandler] = None):
        # 传统模式的正则表达式
        # 测试用例ID匹配模式 - 匹配符合"// TC001 STEP1:"格式的注释行
        self.test_case_pattern = re.compile(r'//\s*(TC\d+\s+STEP\d+):', re.IGNORECASE)
        
        # 单行代码匹配模式 - 匹配"// code: [代码内容]"格式
        self.single_line_code_pattern = re.compile(r'//\s*code:\s*(.*)')
        
        # 多行代码开始和结束标记
        self.multi_line_start = '/* code:'
        self.multi_line_end = '*/'
        
        # 新格式锚点匹配模式 - 匹配符合"// TC001 STEP1 segment1"格式的注释行
        # 修改正则表达式使其更宽松，匹配多个空格并允许更多可能的格式变化
        self.anchor_pattern = re.compile(r'//\s*(TC\d+\s+\s*STEP\d+\s+\s*\w+).*', re.IGNORECASE)
        
        # YAML处理器
        self.yaml_handler = yaml_handler
    
    def set_yaml_handler(self, yaml_handler: YamlStubHandler):
        """
        设置YAML处理器
        
        Args:
            yaml_handler: YAML处理器实例
        """
        self.yaml_handler = yaml_handler
    
    def parse_file(self, file_path: str, content: Optional[str] = None) -> List[Dict[str, Any]]:
        """
        解析文件中的桩注释
        
        支持两种模式：
        1. 传统模式：从注释的code字段中提取代码
        2. 分离模式：识别锚点，从YAML中加载代码
        
        Args:
            file_path: 文件路径
            content: 可选的文件内容，如果提供则不再读取文件
            
        Returns:
            List[Dict[str, Any]]: 解析出的桩点列表
        """
        # 读取文件内容
        if content is None:
            content, encoding = read_file(file_path)
            if content is None:
                logger.error(f"无法读取文件: {file_path}")
                return []
        
        lines = content.splitlines()
        
        # 优先使用新格式解析（锚点与桩代码分离机制）
        stub_points = self.parse_new_format(file_path, lines)
        
        # 如果没有找到新格式的锚点，或YAML处理器不可用，则尝试传统格式
        if not stub_points:
            logger.info(f"未找到新格式锚点，尝试传统格式解析: {file_path}")
            stub_points = self.parse_traditional_format(file_path, lines)
        
        logger.info(f"在文件 {file_path} 中找到 {len(stub_points)} 个桩点")
        return stub_points
    
    def parse_new_format(self, file_path: str, lines: List[str]) -> List[Dict[str, Any]]:
        """
        解析新格式的锚点标识，在锚点位置插入桩代码
        
        支持两种模式：
        1. 基于锚点匹配：识别文件中的"// TC001 STEP1 segment1"格式锚点，并在该位置插入对应代码
        2. 全局插入模式：当文件中没有锚点时，在文件开头插入所有YAML中定义的桩代码
        
        Args:
            file_path: 文件路径
            lines: 文件内容行列表
            
        Returns:
            List[Dict[str, Any]]: 解析出的桩点列表
        """
        if not self.yaml_handler:
            logger.warning("YAML处理器未配置，无法使用锚点与桩代码分离功能")
            return []
        
        logger.info(f"开始处理文件 {file_path}")
        
        # 获取YAML中定义的所有测试用例
        test_cases = self.yaml_handler.get_all_test_cases()
        logger.info(f"YAML配置中存在的测试用例: {test_cases}")
        
        stub_points = []
        
        # 首先在文件中查找锚点
        found_anchors = False
        for i, line in enumerate(lines):
            match = self.anchor_pattern.search(line)
            if match:
                found_anchors = True
                anchor_text = match.group(1).strip()
                logger.info(f"在文件 {file_path} 的第 {i+1} 行找到锚点: {anchor_text}")
                
                # 解析锚点标识
                try:
                    parts = anchor_text.split()
                    # 仅获取前三个部分作为TC_ID, STEP_ID和segment_ID，不管中间有多少空格
                    tc_parts = []
                    for part in parts:
                        if part.strip():  # 确保不是空字符串
                            tc_parts.append(part.strip())
                    
                    logger.debug(f"锚点解析结果: 原始文本='{anchor_text}', 解析部分={tc_parts}")
                    
                    # 确保至少有三个部分
                    if len(tc_parts) >= 3:
                        tc_id = tc_parts[0]
                        step_id = tc_parts[1]
                        segment_id = tc_parts[2]
                        
                        # 从YAML配置中获取对应的桩代码
                        code = self.yaml_handler.get_stub_code(tc_id, step_id, segment_id)
                        
                        if code:
                            logger.info(f"为锚点 {anchor_text} 找到桩代码")
                            # 添加到桩点列表，在锚点所在行的下一行插入
                            stub_points.append({
                                'test_case_id': anchor_text,
                                'code': code,
                                'line_number': i + 1,  # 在当前锚点行之后插入
                                'original_line': i,
                                'file': file_path,
                                'format': 'new'  # 标记为新格式
                            })
                        else:
                            logger.warning(f"未找到锚点 {anchor_text} 对应的桩代码")
                    else:
                        logger.warning(f"锚点 '{anchor_text}' 格式不正确, 无法解析出三个部分 (TC_ID, STEP_ID, segment_ID)")
                except Exception as e:
                    logger.error(f"解析锚点时发生错误: {anchor_text}, 错误: {e}")
        
        # 如果文件中没有找到锚点，则在文件开头一次性插入所有桩代码（保留原有行为）
        if not found_anchors:
            logger.info(f"文件 {file_path} 中未找到锚点，将在文件开头插入所有桩代码")
            # 在文件的最前面添加所有定义的测试用例的桩代码
            for tc_id in test_cases:
                # 获取该测试用例下的所有步骤
                steps = self.yaml_handler.get_steps_for_test_case(tc_id)
                
                for step_id in steps:
                    # 获取该步骤下的所有代码段
                    segments = self.yaml_handler.get_segments_for_step(tc_id, step_id)
                    
                    for segment_id in segments:
                        # 获取代码段内容
                        code = self.yaml_handler.get_stub_code(tc_id, step_id, segment_id)
                        
                        if code:
                            logger.info(f"为文件 {file_path} 准备插入桩代码: {tc_id} {step_id} {segment_id}")
                            
                            # 添加到桩点列表，在文件开头插入
                            stub_points.append({
                                'test_case_id': f"{tc_id} {step_id} {segment_id}",
                                'code': code,
                                'line_number': 1,  # 在文件开头插入
                                'original_line': 0,
                                'file': file_path,
                                'format': 'new'  # 标记为新格式
                            })
        
        logger.info(f"文件 {file_path} 将插入 {len(stub_points)} 个桩点")
        return stub_points
    
    def parse_traditional_format(self, file_path: str, lines: List[str]) -> List[Dict[str, Any]]:
        """
        解析传统格式的注释和code字段
        
        识别"// TC001 STEP1:"格式的注释和相关的code字段。
        
        Args:
            file_path: 文件路径
            lines: 文件内容行列表
            
        Returns:
            List[Dict[str, Any]]: 解析出的桩点列表
        """
        stub_points = []
        i = 0
        while i < len(lines):
            line = lines[i]
            # 查找测试用例ID注释
            match = self.test_case_pattern.search(line)
            if match:
                test_case_id = match.group(1)
                code = None
                insert_line = i
                
                # 检查下一行是否包含code字段
                if i + 1 < len(lines):
                    next_line = lines[i + 1]
                    
                    # 处理单行代码
                    code_match = self.single_line_code_pattern.search(next_line)
                    if code_match:
                        code = code_match.group(1)
                        insert_line = i + 1
                    
                    # 处理多行代码
                    elif self.multi_line_start in next_line:
                        code_lines = []
                        j = i + 2
                        while j < len(lines) and self.multi_line_end not in lines[j]:
                            code_lines.append(lines[j])
                            j += 1
                        
                        if code_lines:
                            code = '\n'.join(code_lines)
                            insert_line = j if j < len(lines) else i + 1
                
                if code:
                    logger.info(f"找到传统格式桩点: {test_case_id} (行 {i+1})")
                    stub_points.append({
                        'test_case_id': test_case_id,
                        'code': code,
                        'line_number': insert_line + 1,
                        'original_line': i,
                        'file': file_path,
                        'format': 'traditional'  # 标记为传统格式
                    })
            
            i += 1
        
        return stub_points
    
    def process_file(self, file_path: str) -> Tuple[bool, str, int]:
        """
        处理文件，解析锚点并插入桩代码
        
        Args:
            file_path: 文件路径
            
        Returns:
            Tuple[bool, str, int]: (成功状态, 消息, 插入桩点数量)
        """
        try:
            # 读取文件内容
            content, encoding = read_file(file_path)
            if content is None:
                return False, f"无法读取文件: {file_path}", 0
            
            # 解析文件中的桩点
            stub_points = self.parse_file(file_path, content)
            
            if not stub_points:
                logger.info(f"文件中未找到需要插入的桩点: {file_path}")
                return True, "无需更新", 0
                
            # 按行号逆序排序，从后往前插入，避免行号变化
            stub_points.sort(key=lambda x: x['line_number'], reverse=True)
            
            # 分割内容为行
            lines = content.splitlines()
            
            # 插入桩代码
            for stub_point in stub_points:
                line_num = stub_point['line_number']
                line_num = min(line_num, len(lines))  # 确保不超出范围
                
                # 获取缩进级别
                indent = ''
                if line_num > 0 and line_num <= len(lines):
                    # 计算前导空格
                    current_line = lines[line_num - 1]
                    indent_match = re.match(r'^(\s*)', current_line)
                    if indent_match:
                        indent = indent_match.group(1)
                
                # 处理多行代码，为每行添加相同缩进和注释标记
                code_lines = stub_point['code'].splitlines()
                formatted_code = []
                for code_line in code_lines:
                    formatted_code.append(f"{indent}{code_line}  // 通过桩插入")
                
                # 在指定位置插入代码
                lines.insert(line_num, "\n".join(formatted_code))
            
            # 将处理后的内容写回文件
            new_content = "\n".join(lines)
            success = write_file(file_path, new_content, encoding)
            
            if success:
                return True, f"成功处理文件，插入了 {len(stub_points)} 个桩点", len(stub_points)
            else:
                return False, "写入文件失败", 0
                
        except Exception as e:
            error_msg = f"处理文件时出错: {str(e)}"
            logger.error(error_msg)
            import traceback
            logger.error(traceback.format_exc())
            return False, error_msg, 0


# 保留这些实用函数，从原文件中保留
def detect_encoding(file_path):
    """检测文件编码"""
    try:
        with open(file_path, 'rb') as f:
            raw_data = f.read(min(1024 * 1024, os.path.getsize(file_path)))
        
        import chardet
        result = chardet.detect(raw_data)
        encoding = result['encoding'] or 'utf-8'
        confidence = result['confidence']
        logger.info(f"检测到文件 {file_path} 编码: {encoding}, 置信度: {confidence}")
        
        # 常见编码修正
        if encoding.lower() in ('gb2312', 'gbk'):
            return 'gb18030'
        return encoding
    except Exception as e:
        logger.error(f"检测文件 {file_path} 编码失败: {str(e)}")
        return 'utf-8'

def read_file(file_path):
    """读取文件内容，自动处理编码"""
    # 尝试的编码列表
    encodings_to_try = []
    
    # 首先尝试检测编码
    detected_encoding = detect_encoding(file_path)
    encodings_to_try.append(detected_encoding)
    
    # 添加其他常用编码
    for enc in ['utf-8', 'gb18030', 'gbk', 'latin1']:
        if enc != detected_encoding:
            encodings_to_try.append(enc)
    
    # 尝试使用不同的编码读取文件
    for encoding in encodings_to_try:
        try:
            logger.info(f"尝试使用编码 {encoding} 读取文件 {file_path}")
            with open(file_path, 'r', encoding=encoding, errors='replace') as f:
                content = f.read()
                logger.info(f"使用编码 {encoding} 成功读取文件 {file_path}")
                return content, encoding
        except UnicodeDecodeError:
            logger.warning(f"使用编码 {encoding} 读取文件 {file_path} 失败")
            continue
        except Exception as e:
            logger.error(f"读取文件 {file_path} 失败: {str(e)}")
            break
    
    # 如果所有编码都失败，使用二进制模式读取并返回
    try:
        logger.warning(f"所有编码尝试失败，以二进制模式读取文件 {file_path}")
        with open(file_path, 'rb') as f:
            binary_content = f.read()
            # 将二进制内容转换为字符串，替换不可解码的字节
            text_content = binary_content.decode('utf-8', errors='replace')
            return text_content, 'utf-8'
    except Exception as e:
        logger.error(f"以二进制模式读取文件 {file_path} 失败: {str(e)}")
        return None, None

def write_file(file_path, content, encoding=None):
    """写入文件内容，使用原始编码"""
    if not encoding:
        # 如果未指定编码，尝试检测原文件编码
        if os.path.exists(file_path):
            encoding = detect_encoding(file_path)
        else:
            encoding = 'utf-8'
    
    try:
        # 创建备份文件
        if os.path.exists(file_path):
            backup_file_path = file_path + ".bak"
            try:
                # 复制原文件作为备份
                with open(file_path, 'r', encoding=encoding, errors='replace') as f_src:
                    src_content = f_src.read()
                with open(backup_file_path, 'w', encoding=encoding, errors='replace') as f_bak:
                    f_bak.write(src_content)
                logger.info(f"创建备份文件: {backup_file_path}")
            except Exception as bak_error:
                logger.warning(f"创建备份文件失败: {backup_file_path}, 错误: {str(bak_error)}")
        
        # 为处理后的文件添加后缀
        stub_file_path = file_path + ".stub"
        
        # 写入处理后的文件
        with open(stub_file_path, 'w', encoding=encoding, errors='replace') as f:
            f.write(content)
        logger.info(f"成功写入处理后文件: {stub_file_path}")
        
        return True
    except Exception as e:
        logger.error(f"写入文件 {file_path} 失败: {str(e)}")
        return False

def find_c_files(root_dir):
    """查找目录下所有.c文件"""
    files = []
    logger.info(f"在目录 {root_dir} 中查找.c源文件")
    
    try:
        # 规范化路径
        root_dir = os.path.normpath(root_dir)
        
        # 确保目录存在
        if not os.path.exists(root_dir):
            logger.error(f"目录不存在: {root_dir}")
            return []
        
        if not os.path.isdir(root_dir):
            logger.error(f"路径不是目录: {root_dir}")
            return []
        
        # 输出目录内容
        try:
            top_files = os.listdir(root_dir)
            logger.info(f"目录 {root_dir} 内容: {top_files}")
        except Exception as e:
            logger.error(f"列出目录内容失败: {root_dir} - {str(e)}")
        
        # 遍历目录查找C源文件
        for root, dirs, file_names in os.walk(root_dir):
            logger.debug(f"扫描目录: {root}, 包含 {len(file_names)} 个文件")
            for file_name in file_names:
                # 只包含以.c结尾的文件
                if file_name.lower().endswith('.c'):
                    full_path = os.path.join(root, file_name)
                    logger.info(f"找到C源文件: {full_path}")
                    files.append(full_path)
        
        # 如果没有找到文件，尝试其他扩展名
        if not files:
            logger.warning(f"在目录 {root_dir} 中没有找到.c文件，尝试使用示例文件")
            # 检查demo.c文件
            demo_path = os.path.join(root_dir, "demo.c")
            if os.path.exists(demo_path):
                logger.info(f"找到示例文件: {demo_path}")
                files.append(demo_path)
            else:
                # 尝试DEMO.c
                demo_path = os.path.join(root_dir, "DEMO.c")
                if os.path.exists(demo_path):
                    logger.info(f"找到示例文件: {demo_path}")
                    files.append(demo_path)
                else:
                    # 如果没有示例文件，创建一个示例C文件
                    demo_path = os.path.join(root_dir, "sample.c")
                    try:
                        with open(demo_path, "w", encoding="utf-8") as f:
                            f.write('''
/**
 * 自动生成的示例C文件
 */
#include <stdio.h>

// 示例函数
void test_function(int value) {
    // 示例注释
    printf("Value: %d\\n", value);
}

int main() {
    printf("Sample C file for YAMLWeave\\n");
    test_function(42);
    return 0;
}
''')
                        logger.info(f"创建了示例C文件: {demo_path}")
                        files.append(demo_path)
                    except Exception as e:
                        logger.error(f"创建示例文件失败: {str(e)}")
        
        logger.info(f"总共找到 {len(files)} 个.c源文件")
        if files:
            for i, f in enumerate(files):
                logger.info(f"文件 {i+1}: {f}")
        return files
    except Exception as e:
        logger.error(f"查找文件时出错: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return []


def create_example_yaml_file(target_path):
    """创建示例YAML配置文件"""
    logger.info(f"尝试创建示例YAML配置文件: {target_path}")
    try:
        # 确保目录存在
        os.makedirs(os.path.dirname(target_path), exist_ok=True)
        
        example_content = '''# YAMLWeave 测试用桩代码配置文件
# 按测试用例、步骤和代码段分级组织

# ==== 基础功能测试用例 ====

# TC001: 数据验证测试
TC001:
  # STEP1: 输入边界检查
  STEP1:
    # segment1: 检查数值范围
    segment1: |
      if (data < 0 || data > 100) {
          printf("无效数据: %d\\n", data);
          return -1;
      }
    # segment2: 检查完成记录
    segment2: |
      printf("数据边界验证完毕\\n");

  # STEP2: 格式验证
  STEP2:
    # segment1: 检查数据格式
    segment1: |
      if (!is_valid_format(data.format)) {
          printf("无效的数据格式: %s\\n", data.format);
          return -1;
      }

# TC002: 性能监控测试
TC002:
  # STEP1: 计时器操作
  STEP1:
    # segment1: 开始计时
    segment1: |
      uint64_t start_time = get_current_time_ms();
      log_performance("开始性能监控");
    
    # segment2: 结束计时
    segment2: |
      uint64_t end_time = get_current_time_ms();
      log_performance("处理耗时: %llu ms", (end_time - start_time));

# ==== 高级功能测试用例 ====

# TC101: 复杂锚点格式测试 - 测试多种锚点格式变体
TC101:
  # STEP1: 标准格式测试
  STEP1:
    # 标准格式锚点 TC101 STEP1 segment1
    segment1: |
      printf("标准格式锚点测试成功\\n");
    
    # 特殊命名锚点 TC101 STEP1 format_check
    format_check: |
      if (data == NULL) {
          printf("数据为空\\n");
          return NULL_ERROR;
      }
  
  # STEP2: 特殊格式测试
  STEP2:
    # 无空格锚点测试(//TC101 STEP2 segment1)
    segment1: |
      printf("无空格锚点测试\\n");
    
    # 多空格锚点测试(//  TC101   STEP2   multi_space)
    multi_space: |
      printf("多空格锚点测试\\n");

# TC102: 复杂代码结构测试 - 测试复杂缩进和多行代码
TC102:
  STEP1:
    complex_code: |
      if (condition) {
          for (int i = 0; i < limit; i++) {
              if (i % 2 == 0) {
                  result += calculate(i);
                  
                  if (result > threshold) {
                      printf("阈值 %d 超出: %d\\n", threshold, result);
                      break;
                  }
              } else {
                  result -= penalty;
              }
          }
      } else {
          printf("条件不满足\\n");
          return DEFAULT_RESULT;
      }

# TC103: 特殊字符测试 - 测试包含特殊字符的桩代码
TC103:
  STEP1:
    special_chars: |
      printf("特殊字符测试: \\\" \\\\ \\' \\n \\t");
      char* path = "C:\\\\Program Files\\\\Test\\\\";
      if (strcmp(input, "特殊值\"引号") == 0) {
          return SPECIAL_VALUE;
      }

# TC104: 长代码段测试 - 测试超长代码段的处理
TC104:
  STEP1:
    long_segment: |
      // 这是一个非常长的代码段，测试工具对长代码的处理能力
      const char* message = "这是一个很长的消息，测试YAML解析器和桩插入工具对长字符串的处理";
      printf("开始执行长代码段...\\n");
      
      int result = 0;
      int iterations = 50;
      
      for (int i = 0; i < iterations; i++) {
          result += i * calculate_factor(i);
          log_progress("长操作进度", i, iterations);
          
          if (i % 10 == 0) {
              printf("已完成 %d%% \\n", (i * 100) / iterations);
              
              if (check_cancellation()) {
                  printf("操作被取消\\n");
                  cleanup_resources();
                  return OPERATION_CANCELLED;
              }
          }
      }
      
      log_result("长操作结果", result);
      printf("长代码段执行完毕\\n");
      return result;

# ==== 性能测试用例 ====

# TC201: 性能压力测试 - 用于测试处理大量桩点的性能
TC201:
  STEP1:
    # 简单但会被多次调用的桩点
    segment1: |
      performance_counter++;
      if (performance_counter % 1000 == 0) {
          printf("性能计数: %d\\n", performance_counter);
      }

# ==== 边界情况测试 ====

# TC301: 边界情况测试 - 测试各种边界情况
TC301:
  STEP1:
    # 空代码段测试
    empty_segment: |
      
    # 单行代码段测试
    one_line: |
      return SPECIAL_RESULT;
    
    # 包含注释的代码段
    with_comments: |
      // 这是代码段中的注释
      /* 
       * 这是多行注释
       */
      printf("包含注释的代码段\\n");  // 行尾注释
'''
        
        with open(target_path, 'w', encoding='utf-8') as f:
            f.write(example_content)
        
        logger.info(f"成功创建示例YAML配置文件: {target_path}")
        return True
    except Exception as e:
        logger.error(f"创建示例YAML配置文件失败: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return False 