"""YAMLWeave Core u5305 - u63d0u4f9bYAMLWeaveu7684u6838u5fc3u529fu80fd"""

__version__ = "1.0.0"

# u4f7fu7eddu5bf9u5bfcu5165u7684u6a21u5757u66f4u6613u4e8eu8bbfu95ee
from code.core.stub_processor import StubProcessor 